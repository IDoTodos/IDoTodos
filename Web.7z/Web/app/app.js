var app = angular.module("iDo", [
							"ngRoute",
                            
                            "ngMaterial"
                        ]);

app.config(['$routeprovider',
 function ($routeprovider) {
            $routeprovider.
            when('/guestlist', {
                templateurl: 'app/guestlist/views/guestlist.html',
                controller: ''
            }).
            otherwise({
                redirectto: '/guestlist'
            });

 }]);


app.run(function ($rootScope, $location) {
    // $rootScope.checkUser = function () {
        // if (localStorageService.get('user') == null) {
            // $location.path("/Login");
        // }
    // }

});